# Queries used in selected Databases
## General Queries

- ("AI-assisted programming" OR "AI coding assistant" OR "code generation" OR "large language models")
AND
("software engineering" OR "software development")
AND
(productivity OR "code quality" OR evaluation OR efficiency)
- (("AI coding assistant" OR "GitHub Copilot" OR "code generation") 
AND
("software development")
AND
(productivity OR "code quality"))
AND
(stype.exact(("Scholarly Journals" OR "Conference Papers & Proceedings") NOT ("Trade Journals" OR "Working Papers"))
AND pd(20200101-20260403)
AND PEER(yes))
- (("AI-assisted programming" OR "AI coding assistant" OR "code generation" OR "large language models") AND ("software engineering" OR "software development") AND (productivity OR "code quality" OR evaluation OR efficiency)) AND stype.exact("Scholarly Journals" OR "Conference Papers & Proceedings") AND (stype.exact(("Scholarly Journals" OR "Conference Papers & Proceedings") NOT ("Trade Journals" OR "Working Papers")) AND pd(20200101-20260403) AND PEER(yes))
- (("AI-assisted programming" OR "AI coding assistant" OR "code generation" OR "large language models") AND ("software engineering" OR "software development") AND (productivity OR "code quality" OR evaluation OR efficiency)) AND (stype.exact("Scholarly Journals") AND yr(2020-2029) AND PEER(yes))
