# Specific queries
These queries led to opportunistic discoveries in Google and Google Scholar:
- "Evaluating the Impact of AI-Assisted Programming Tools on Enterprise Software Development Workflows"
- "Socio-Technical Dynamics in AI-Augmented Software Teams: An Empirical Study on Coordination and Governance"
- "Measuring Developer Cognitive Load and Fatigue During AI-Assisted Debugging: A Eye-Tracking and EEG Study"
- "The Cost of Overreliance: Empirical Evaluation of Cognitive Offloading in LLM-Based Code Generation"
- "The Economics of Generative AI in Software Engineering: ROI, Cost-Benefit Analysis, and Labor Market Shifts"
- "Trust Calibration and Developer Acceptance of AI Coding Assistants: A Technology Acceptance Model (TAM) Approach"
